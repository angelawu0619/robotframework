Copyright and license
=====================

Robot Framework is open source software provided under the `Apache License
2.0`_. Robot Framework documentation such as this User Guide use the
`Creative Commons Attribution 3.0 Unported`_ license. Most libraries and tools
in the larger ecosystem around the framework are also open source, but they
may use different licenses.

The full Robot Framework copyright notice is included below:

.. include:: ../../../../COPYRIGHT.txt
   :literal:
