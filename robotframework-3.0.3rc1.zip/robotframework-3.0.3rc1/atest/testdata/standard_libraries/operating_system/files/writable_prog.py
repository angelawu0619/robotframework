import sys


print(sys.stdin.read().upper())

