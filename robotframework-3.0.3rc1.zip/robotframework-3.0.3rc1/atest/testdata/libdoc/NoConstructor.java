/** No inits here! */
public class NoConstructor {
   /** The only lonely keyword. */
   public void keyword(String arg1, int arg2) {}
}
