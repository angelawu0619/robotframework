class InvalidClass:

    def __init__(self, i, get, no, args):
        pass
