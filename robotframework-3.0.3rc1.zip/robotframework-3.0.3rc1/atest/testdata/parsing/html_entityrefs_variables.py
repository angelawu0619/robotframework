scandinavian_letters = u'Hyv\xE4\xE4 \xFC\xF6t\xE4 \xC5\xC4\xD6'
xml_escapes = '''& &amp; <tag> ' " &gt;'''
other_escapes = u'''\xA7xxx \u02DC ~'''
