This text is ignored even if this is not a comment.


===========  ===============  =======  ==================
 Test Case      Action          Arg           Arg
===========  ===============  =======  ==================
Suite2 Test  [Documentation]  FAIL	   Expected failure	
\            Fail             ${msg}   \
# This text  is ignored       because  this is a comment.
===========  ===============  =======  ==================


=========  ================
Variables  \
${msg}	   Expected failure
=========  ================
