public class JavaLibraryWithoutPublicConstructor {
    protected JavaLibraryWithoutPublicConstructor() {}
}
