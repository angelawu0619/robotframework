variables2 = 'Variable from variables2.py'
