class SomeObject:
    pass

some_object = SomeObject()
some_string = 'Hello, World!'

def keyword():
    pass
