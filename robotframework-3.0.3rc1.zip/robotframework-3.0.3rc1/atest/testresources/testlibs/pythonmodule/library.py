library = "It should be OK to have an attribute with same name as the module"


def keyword_from_submodule(arg='World'):
    return "Hello, %s!" % arg
