package javalibraryscope;

public class InvalidEmpty extends BaseLib{
	
}