package javalibraryscope;

public class InvalidValue extends BaseLib{
	
	public static String ROBOT_LIBRARY_SCOPE = "invalid"; 
	
}